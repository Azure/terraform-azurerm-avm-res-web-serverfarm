# Placeholder install script
Write-Host 'Installing fonts...'
